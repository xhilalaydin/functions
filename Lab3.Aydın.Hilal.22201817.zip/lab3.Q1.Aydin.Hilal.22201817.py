# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 08:35:50 2023

@author: hilala-ug
"""

"""
a. Write a function sum_without_twenties() that returns the sum of three integer arguments
a, b, and c. However, do not include any integer as part of the sum if it is within the
range [20, 29] (inclusive).

b. Write a program that inputs three integers and displays their sum by using the
sum_without_twenties function. The program will continue to take inputs until any
negative number is entered.

Sample Run : (User inputs are in red)
Enter first integer: 14
Enter second integer: 25
Enter third integer: 18
Sum of 14 25 18 without twenties is 32

Enter first integer: 21
Enter second integer: 22
Enter third integer: 23
Sum of 21 22 23 without twenties is 0

Enter first integer: 12
Enter second integer: 45
Enter third integer: 30
Sum of 12 45 30 without twenties is 87

Enter first integer: 23
Enter second integer: -4
Enter third integer: 12
"""

def sum_of_twenties(no1,no2,no3):
    summ = 0
    if no1 not in range(20,30):
        summ += no1
    if no2 not in range(20,30):
        summ += no2
    if no3 not in range(20,30):
        summ += no3
    return summ

"""
function takes three integers and if
the integers not within the range(20 , 30)
add them together.Their addition makes up the summ
Parameters:
param1 (no1): first integer putted in as input by the user
param2(no2):  second integer putted in as input by the user
param3 (no3): third integer putted in as input by the user

Returns:summ(no1 + no2 + no3)
type: value
"""

num1 = int(input("Enter first integer: "))
num2 = int(input("Enter second integer: "))
num3 = int(input("Enter third integer: "))

while num1 > 0 and num2 > 0 and num3 > 0:

    summ = sum_of_twenties(num1, num2, num3)
    
    print("Sum of", num1,num2,num3,f"without twenties is {summ}" )
    
    num1 = int(input("Enter first integer: "))
    num2 = int(input("Enter second integer: "))
    num3 = int(input("Enter third integer: "))