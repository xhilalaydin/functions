# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 09:05:03 2023

@author: hilala-ug
"""
"""
a. Write a function, get_substring_positions() that accepts two strings as arguments. It will
return the number of the positions where they contain the same substring of length 2.
For example, "docatzz" and "dobatz" should yield 3, since the "do", "at", and "tz"
substrings appear in the same place in both strings.

b. Write a program to take a number of two strings and call the above function and display
the result. The program will stop when the first string is an empty string.

Sample Run: (User inputs are in red)
Enter first string: docatzz
Enter second string: dobatz
"docatzz" and "dobatz" have 3 positions where they contain
the same substrings of length 2

Enter first string: conversation
Enter second string: done
"conversation" and "done" have 1 positions where they contain
the same substrings of length 2

Enter first string: examination
Enter second string: discrimination
"examination" and "discrimination" have 0 positions where
they contain the same substrings of length 2

Enter first string:
Enter second string: finished
"""

def get_substring_positions(str1 ,str2):
    count = 0
    if len(str1) > len(str2):
        for i in range(len(str1)-1):
            substr1 = str1[i:i+2:]
            substr2 = str2[i:i+2:]
            if substr1 == substr2:
                count += 1
    else:
        
        for i in range(len(str2)-1):
            substr1 = str1[i:i+2:]
            substr2 = str2[i:i+2:]
            if substr1 == substr2:
                count += 1
    return count 

"""
function takes two strings and counts the number of substrings
of length 2 in the same index of both strings
Parameters:
str1: the first string inputted by the user
str2: the second string inputted by the user

Returns:count(the number of same substrings on the same index)
type: integer
"""

    
firstw = str(input("Enter first string: "))
secondw = str(input("Enter second string: "))


    
while firstw != "":
    number = get_substring_positions(firstw,secondw)
    print(firstw, "and", secondw, f"have {number} positions where they contain the same substrings of length 2")
    
    firstw = str(input("Enter first string: "))
    secondw = str(input("Enter second string: "))
