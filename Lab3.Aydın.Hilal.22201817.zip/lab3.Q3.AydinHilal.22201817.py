# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 09:57:59 2023

@author: hilala-ug
"""
"""
a) Write a function called getSuffix(), that takes two int parameters, number and
sizeOfSuffix, and returns an integer value that is the suffix of number having the
specified number of digits, i.e. sizeOfSuffix.
For example, getSuffix( 12345, 3 ) returns the value 345 and getSuffix( 1234567, 2 )
returns the value 67.
Note: DO NOT use Strings in your solution and Math module.

b) Write a function called getNoOfDigits() that takes a single int parameter, n, and returns
the number of digits in n. Even though it will be very inefficient, you MUST USE ONLY
your getSuffix method (from part a above) to do this.

c. Write a program to input 3 integer numbers and the number of the digits of the suffix and
return the suffix of each number and the number of digits in each number using the
above two methods.

Sample Run: (User inputs are in red)
Enter an integer number: 34673
Enter the number of digits of suffix: 3
The suffix is: 673
The number of digits of 34673 is 5

Enter an integer number: 12
Enter the number of digits of suffix: 4
The suffix is: 12
The number of digits of 12 is 2

Enter an integer number: 1234
Enter the number of digits of suffix: 1
The suffix is: 4
The number of digits of 1234 is 4
"""

def getSuffix(num, size):
    divisor = 10** size
    suffix = num % divisor
    return suffix

"""
function takes a integer and a size ,
then returns the desired suffixed in the length of size

Parameters:
num: the integer inputted by the user
size: size of the desired suffix 

Returns: suffix of the integer in the length of size
type: integer
"""


def getNoOfdigits(n):
    size = 1
    while n != getSuffix(n, size):
        size += 1
    return size

"""
function takes a single number,
checks the suffixes starting with length 1,
until the suffix length stays the same though size increases

Parameters:
n: the number inputted by user

Returns: at which size suffix is the same to the previous one
"""
number = int(input("Enter an integer number: "))
size = int(input("Enter the number of digits of suffix: "))

suf= getSuffix(number, size)

no = getNoOfdigits(number)

print(f"The suffix is: {suf}")

print(f"The number of digits of {number} is {no}")







